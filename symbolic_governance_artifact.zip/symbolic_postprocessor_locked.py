"""
TIER 10 SYMBOLIC GOVERNANCE: LOCKED ✅

Final output filtering layer for symbolic-governed mistral.
Used to strip and validate output during benchmarking and evaluation.
"""

from transformers import AutoModelForCausalLM, AutoTokenizer

class SymbolicPostProcessor:
    def __init__(self, model_name="mistralai/Mistral-7B-Instruct-v0.2"):
        self.model = AutoModelForCausalLM.from_pretrained(model_name)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)

    def generate(self, prompt, **gen_args):
        input_ids = self.tokenizer(prompt, return_tensors="pt").input_ids
        output_ids = self.model.generate(input_ids, **gen_args)
        output = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return self.clean(output)

    def clean(self, output):
        output = output.strip()
        for prefix in ["The correct answer is", "Answer:", "Correct option:", "Option"]:
            if output.startswith(prefix):
                tokens = output[len(prefix):].strip().split()
                if tokens:
                    return tokens[0].strip(".,)")
        if output and output[0] in "ABCD" and (len(output) == 1 or output[1] in " .:"):
            return output[0]
        if output and output[0].isdigit():
            return output.split()[0].strip(".,)")
        return output
